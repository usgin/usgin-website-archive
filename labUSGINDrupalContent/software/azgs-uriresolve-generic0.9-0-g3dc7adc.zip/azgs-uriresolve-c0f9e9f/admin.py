from models import *
from django.contrib import admin
from django.conf import settings

class acceptMappingInline(admin.TabularInline):
    model = accept_mapping
    extra = 2

class rewrite_ruleAdmin(admin.ModelAdmin):
        
    list_display = ('label', 'uri_expression')
    search_fields = ('label', 'uri_expression')
    
    fieldsets = [
        ('Basic Information', {
            'fields': ['label', 'description']
        }),
        ('URI Expression', {
            'fields': ['uri_expression']
        }),
    ]
    
    inlines = [acceptMappingInline]
            
admin.site.register(rewrite_rule, rewrite_ruleAdmin)
admin.site.register(representation_type)