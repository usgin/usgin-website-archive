-------------------------------------------------------
- BASIC INSTALLATION INSTRUCTIONS                               
-------------------------------------------------------
Prerequisites:
- A functioning Django Project

Steps:
1. Put the uriresolve folder into your project: from your project directory, 
	git clone git://github.com/azgs/uriresolve.git
2. In your project's settings.py, add 'uriresolve' to your list of INSTALLED_APPS
3. Make sure that the following template context processors are defined in your
	project's settings.py:
		TEMPLATE_CONTEXT_PROCESSORS (
			'django.core.context_processors.request',
			'django.core.context_processors.media',
			'django.contrib.auth.context_processors.auth'
		)
4. Add .../uriresolve/templates to your list of TEMPLATE_DIRS, or else symlink 
	/uriresolve/templates/uriresolve into a location already specified.
5. Add .../uriresolve/media/uriresolve to the directory specified as your MEDIA_ROOT.
	This can be done through copy/paste or symlink.
6. Add the following line to the bottom of your patterns in your project's urls.py:
	(r'^', include('uriresolve.urls')),
	- Note: This will capture any traffic to your site that is not recognized by an
		earlier url rule and forward the traffic on to the URI resolver. If this is
		not the desired behavior, adjust this url rule as needed.
7. Run 'python manage.py syncdb'

Acknowledgements:
- HTTP Accept-header parsing is accomplished using the mimeparse module:
	http://code.google.com/p/mimeparse/